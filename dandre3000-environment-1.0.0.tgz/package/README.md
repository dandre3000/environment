# @dandre3000/environment

Check if code is running on the main thread or a worker of a browser, node, bun or deno instance.

# Usage

```js
import { isMainThread } from '@dandre3000/environment'

if (isMainThread) {
  // main thread
} else {
  // worker thread
}
```
